name="Show/Hide Systray"
order=1
