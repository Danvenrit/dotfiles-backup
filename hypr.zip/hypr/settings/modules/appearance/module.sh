#!/bin/bash
_getHeader "$name"

