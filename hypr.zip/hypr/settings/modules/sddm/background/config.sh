name="Background Image"
desxription="Update the background wallpaper of sddm to the current wallpaper."
order=50
author="Stephan Raabe ML4W"
