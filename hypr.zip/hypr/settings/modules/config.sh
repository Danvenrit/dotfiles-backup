name="Settings"
description="The settings script will help you to configure your Hyprland installation."
author="Stephan Raabe ML4W"
order=1
email="mail@ml4w.com"
homepage="https://gitlab.com/stephan-raabe/dotfiles"