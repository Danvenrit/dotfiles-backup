#!/bin/bash
_getHeader "$name" "$author"
vim ~/dotfiles/hypr/conf/custom.conf
_goBack


