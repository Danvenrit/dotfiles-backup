#!/bin/bash

if [ $(cat /sys/class/drm/card1-HDMI-A-1/enabled) = "disabled" ]; then
    echo "source = ~/dotfiles/hypr/conf/monitors/default.conf" > ~/dotfiles/hypr/conf/monitor.conf
elif [ $(cat /sys/class/drm/card1-HDMI-A-1/enabled) = "enabled" ]; then 
    echo "source = ~/dotfiles/hypr/conf/monitors/1920x1080@120.conf" > ~/dotfiles/hypr/conf/monitor.conf
fi 
